<?php 
	
	require_once 'vendor/autoload.php';
	
	$linioC = new \Linio\Main();
	$linioC->execute();

 ?>