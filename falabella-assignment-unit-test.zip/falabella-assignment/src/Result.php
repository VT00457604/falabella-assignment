<?php

namespace Linio;


class Result
{
    public $remainder3;
    public $remainder5;
    public $remainder35;
    public $number;
}