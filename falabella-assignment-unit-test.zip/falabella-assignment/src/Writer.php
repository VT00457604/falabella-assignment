<?php

namespace Linio;


class Writer
{
    function writeAnswer($result) : void
    {
        switch ($result) {
            case ($result->remainder35 == 0 ):
                echo sprintf("%s\n","Linianos");
				//echo "<br/>";
                break;
            case ($result->remainder5 == 0):
                echo sprintf("%s\n","IT");
				//echo "<br/>";
                break;
            case ($result->remainder3==0):
                echo sprintf("%s\n","Linio");
				//echo "<br/>";
                break;
            default:
                echo sprintf("%s\n",$result->number);
				//echo "<br/>";
        }
    }
}